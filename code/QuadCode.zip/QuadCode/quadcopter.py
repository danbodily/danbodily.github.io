#!/usr/bin/env python

import time
import numpy as np
import matplotlib.patches as mpatches
from scipy.integrate import odeint
import plot_helper as ph
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.patches as patches
import kin_helper as kh
import params as P
import control

tf = 4*np.pi
tpoints = np.linspace(0,tf,10000)

#State Variables for all time
global times, pndes,pedes,pddes,pn_r,pe_r,pd_r,psi_r,th_r,phi_r
times = np.array([])
pndes = np.array([])
pedes = np.array([])
pddes = np.array([])
pn_r = np.array([])
pe_r = np.array([])
pd_r = np.array([])
psi_r = np.array([])
th_r = np.array([])
phi_r = np.array([])

#Dynamics Equation
def quadcopter_dynamics(xs,t):
    global times, pndes,pedes,pddes,pn_r,pe_r,pd_r,psi_r,th_r,phi_r
    psi = xs[0]
    th = xs[1]
    phi = xs[2]
    p = xs[3]
    q = xs[4]
    r = xs[5]
    p_n = xs[6]
    p_e = xs[7]
    p_d = xs[8]
    u = xs[9]
    v = xs[10]
    w = xs[11]

    #Euler Angles
    cth = np.cos(th)
    sth = np.sin(th)
    cpsi = np.cos(psi)
    spsi = np.sin(psi)
    cphi = np.cos(phi)
    sphi = np.sin(phi)
    Rot = np.array([[cpsi*cth,spsi*cth,-sth],\
                   [-spsi*cphi+cpsi*sth*sphi,cpsi*cphi+spsi*sth*sphi, cth*sphi],\
                   [-spsi*sphi+cpsi*sth*cphi,-cpsi*sphi+spsi*sth*cphi, cth*cphi]])

    psides = 0
    thdes = 0
    phides = 0
    pdes = 0
    qdes = 0
    rdes = 0

    #Desired Position of Quadcopter - Path Made Up For Now
    p_ndes = .2*np.cos(t)
    p_edes = .2*np.sin(t)
    p_ddes = -.5

    vgdes = np.array([[-.2*np.sin(t)],[.2*np.cos(t)],[0]])
    sdes = Rot.dot(vgdes)

    udes = sdes[0]
    vdes = sdes[1]
    wdes = sdes[2]

    dxs = np.array([[psi-psides],\
                   [th-thdes],\
                   [phi-phides],\
                   [p-pdes],\
                   [q-qdes],\
                   [r-rdes],\
                   [p_n-p_ndes],\
                   [p_e-p_edes],\
                   [p_d-p_ddes],\
                   [u-udes],\
                   [v-vdes],\
                   [w-wdes]])

    times = np.append(times,t)
    pndes = np.append(pndes,p_ndes)
    pedes = np.append(pedes,p_edes)
    pddes = np.append(pddes,p_ddes)

    # dxs = np.array([[x-xd],[xdot-xdesdot],[z-zd],[zdot-zdesdot],[th],[thdot]])

    # #LQR Controller - See Write Up
    A = np.array([[0,0,0,0,0,1.0,0,0,0,0,0,0],\
                  [0,0,0,0,1.0,0,0,0,0,0,0,0],\
                  [0,0,0,1.0,0,0,0,0,0,0,0,0],\
                  [0,0,0,0,0,0,0,0,0,0,0,0.0],\
                  [0,0,0,0,0,0,0,0,0,0,0,0.0],\
                  [0,0,0,0,0,0,0,0,0,0,0,0.0],\
                  [0,0,0,0,0,0,0,0,0,1.0,0,0],\
                  [0,0,0,0,0,0,0,0,0,0,1.0,0],\
                  [0,0,0,0,0,0,0,0,0,0,0,1.0],\
                  [0,-P.g,0,0,0,0,0,0,0,0,0,0.0],\
                  [0,0,P.g,0,0,0,0,0,0,0,0,0.0],\
                  [0,0,0,0,0,0,0,0,0,0,0,0.0]])

    k = .5
    B = np.array([[0,0,0,0],\
                  [0,0,0,0],\
                  [0,0,0,0],\
                  [P.L/P.Ixx,-P.L/P.Ixx,0,0],\
                  [0,0,P.L/P.Iyy,-P.L/P.Iyy],\
                  [k/P.Izz,k/P.Izz,-k/P.Izz,-k/P.Izz],\
                  [0,0,0,0],\
                  [0,0,0,0],\
                  [0,0,0,0],\
                  [0,0,0,0],\
                  [0,0,0,0],\
                  [-1.0/P.m,-1.0/P.m,-1.0/P.m,-1.0/P.m]])

    Q = np.diag([.1,.1,.1,.1,.1,.1,10.0,10.0,10.0,1,1,1])
    R = np.eye(4)*.01
    K, S, E = control.lqr(A,B,Q,R)
    U = -K.dot(dxs)

    Fl = U[0]+P.m*P.g/4.0
    Fr = U[1]+P.m*P.g/4.0
    Ff = U[2]+P.m*P.g/4.0
    Fb = U[3]+P.m*P.g/4.0

    tau_r = k*Fl
    tau_l = k*Fr
    tau_f = k*Ff
    tau_b = k*Fb

    #Dynamics
    #Fast Angles

    pdot = (Fl-Fr)*P.L/P.Ixx+(P.Iyy-P.Izz)*q*r/P.Ixx
    qdot = (Ff-Fb)*P.L/P.Iyy+(P.Izz-P.Ixx)*p*r/P.Iyy
    rdot = (tau_r+tau_l-tau_f-tau_b)/P.Izz+(P.Ixx-P.Iyy)*p*q/P.Izz

    Binv = np.array([[0,sphi/cth,cphi/cth],[0,cphi,-sphi],[1.0,sth/cth*sphi,sth*cphi/cth]])
    states= Binv.dot(np.array([[p],[q],[r]]))
    psidot = states[0]
    thdot = states[1]
    phidot = states[2]

    udot = r*v-q*w-P.g*sth
    vdot = p*w-r*u+P.g*cth*sphi
    wdot = q*u-p*v+P.g*cth*cphi-1.0/P.m*(Ff+Fb+Fl+Fr)

    states =  Rot.transpose().dot(np.array([[u],[v],[w]]))
    p_ndot = states[0]
    p_edot = states[1]
    p_ddot = states[2]
    states =[psidot,thdot,phidot,pdot,qdot,rdot,p_ndot,p_edot,p_ddot,udot,vdot,wdot]

    return states

#Simulation
y = odeint(quadcopter_dynamics,P.initial_states,tpoints)
print("Done Integrating")

#Graphs
plt.figure()
plt.suptitle("Quadcopter Trajectory")
plt.subplot(311)
plt.plot(tpoints,y[:,6])
plt.plot(times,pndes,'r')
plt.xlabel("time")
plt.ylabel("pn_position")
red_patch = mpatches.Patch(color='blue', label='Actual')
blue_patch = mpatches.Patch(color='red', label='Desired')
plt.legend(handles=[red_patch,blue_patch])

plt.subplot(312)
plt.plot(tpoints,y[:,7])
plt.plot(times,pedes,'r')
plt.xlabel("time")
plt.ylabel("pe_position")

plt.subplot(313)
plt.plot(tpoints,y[:,8])
plt.plot(times,pddes,'r')
plt.xlabel("time")
plt.ylabel("pd_position")
plt.show()

# #Visualization
fig = plt.figure(1)
fig.show()
plt.ion()
ax = plt.gca(projection='3d')

start = time.time()
factor = .50 #1.0 - REAL TIME - .5 - HALF SPEED
dt = 0
while (dt*factor < tpoints[-1]):
    dt = (time.time()-start)
    i = np.argmax(tpoints > dt*factor)
    it = np.argmax(times > dt*factor)

    #Current State
    pn = y[i,6]
    pe = y[i,7]
    pd = y[i,8]
    psi = y[i,0]
    th = y[i,1]
    phi = y[i,2]

    cth = np.cos(th)
    sth = np.sin(th)
    cpsi = np.cos(psi)
    spsi = np.sin(psi)
    cphi = np.cos(phi)
    sphi = np.sin(phi)
    R = np.array([[cpsi*cth,spsi*cth,-sth],\
                   [-spsi*cphi+cpsi*sth*sphi,cpsi*cphi+spsi*sth*sphi, cth*sphi],\
                   [-spsi*sphi+cpsi*sth*cphi,-cpsi*sphi+spsi*sth*cphi, cth*cphi]])

    t = np.array([pn,pe,pd])
    gwb = kh.rot_vec2homog(R,t)

    ax.cla()
    ph.plot_gnomon(ax,np.eye(4))
    # ph.plot_quadcopter(ax,gwb,P.L)
    ph.plot_simple_quadcopter(ax,gwb,P.L) #For Speed
    ax.scatter([pndes[it]],[pedes[it]],[pddes[it]],s=100,c='r')
    ax.set_xlim3d([-.3,.3])
    ax.set_ylim3d([-.3,.3])
    ax.set_zlim3d([-.6,0])
    ax.view_init(elev=225, azim=-45)
    if  dt > 1:
        ax.view_init(elev=225-dt, azim=-45+.5*dt)
    if  dt > 20:
        ax.view_init(elev=205, azim=-35)
    fig.canvas.draw()
    # plt.draw()
    # plt.show()
    plt.pause(.00000001)
