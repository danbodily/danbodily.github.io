#!/usr/bin/env python

import matplotlib.pyplot as plt
import numpy as np
import kin_helper as kh
import matplotlib.patches as patches
from mpl_toolkits.mplot3d import Axes3D

def plot_dicopter(ax,g_world_body,L):
    g_body_front = kh.homog_translate(L,0,0)
    g_world_front = g_world_body.dot(g_body_front)
    plot_ellipse(ax,g_world_front)

    g_body_back = kh.homog_translate(-L,0,0)
    g_world_back = g_world_body.dot(g_body_back)
    # plot_gnomon(ax,g_world_body)
    plot_ellipse(ax,g_world_back)
    a = g_world_front[:3,3]
    b = g_world_back[:3,3]
    plot_line(ax,a,b,'b',2)

def plot_quadcopter(ax,g_world_body,L):
    g_body_front = kh.homog_translate(L,0,0)
    g_world_front = g_world_body.dot(g_body_front)
    plot_ellipse(ax,g_world_front)

    g_body_back = kh.homog_translate(-L,0,0)
    g_world_back = g_world_body.dot(g_body_back)
    plot_ellipse(ax,g_world_back)

    g_body_left = kh.homog_translate(0,-L,0)
    g_world_left = g_world_body.dot(g_body_left)
    plot_ellipse(ax,g_world_left)

    g_body_right = kh.homog_translate(0,L,0)
    g_world_right = g_world_body.dot(g_body_right)
    plot_ellipse(ax,g_world_right)

    a = g_world_front[:3,3]
    b = g_world_back[:3,3]
    plot_line(ax,a,b,'b',2)

    a = g_world_left[:3,3]
    b = g_world_right[:3,3]
    plot_line(ax,a,b,'b',2)

def plot_simple_quadcopter(ax,g_world_body,L):
    g_body_front = kh.homog_translate(L,0,0)
    g_world_front = g_world_body.dot(g_body_front)
    plot_simple_ellipse(ax,g_world_front)

    g_body_back = kh.homog_translate(-L,0,0)
    g_world_back = g_world_body.dot(g_body_back)
    plot_simple_ellipse(ax,g_world_back)

    g_body_left = kh.homog_translate(0,-L,0)
    g_world_left = g_world_body.dot(g_body_left)
    plot_simple_ellipse(ax,g_world_left)

    g_body_right = kh.homog_translate(0,L,0)
    g_world_right = g_world_body.dot(g_body_right)
    plot_simple_ellipse(ax,g_world_right)

    a = g_world_front[:3,3]
    b = g_world_back[:3,3]
    plot_line(ax,a,b,'b',2)

    a = g_world_left[:3,3]
    b = g_world_right[:3,3]
    plot_line(ax,a,b,'b',2)

def plot_gnomon(ax, g, length=0.05, linewidth=5, color=['r', 'g', 'b']):
    x = g.dot(np.array([length, 0.0, 0.0, 1.0]))
    y = g.dot(np.array([0.0, length, 0.0, 1.0]))
    z = g.dot(np.array([0.0, 0.0, length, 1.0]))
    o = g.dot(np.array([0.0, 0.0, 0.0, 1.0]))

    plot_line(ax, o, x, color[0], linewidth)
    plot_line(ax, o, y, color[1], linewidth)
    plot_line(ax, o, z, color[2], linewidth)

def plot_line(ax, a, b, color, linewidth_custom, alpha=1.0):  # Ax must be projection 3d
    ax.plot([a[0], b[0]], [a[1], b[1]], [a[2], b[2]], color=color, linewidth=linewidth_custom, alpha=alpha)
    # Error here may mean you forgot ax projection

def set_axes_equal(ax):
    '''
    Make axes of 3D plot have equal scale so that spheres appear as spheres,
    cubes as cubes, etc..  This is one possible solution to Matplotlib's
    ax.set_aspect('equal') and ax.axis('equal') not working for 3D.

    Input
      ax: a matplotlib axis, e.g., as output from plt.gca().
    '''

    x_limits = ax.get_xlim3d()
    y_limits = ax.get_ylim3d()
    z_limits = ax.get_zlim3d()

    x_range = x_limits[1] - x_limits[0]
    y_range = y_limits[1] - y_limits[0]
    z_range = z_limits[1] - z_limits[0]

    x_mean = np.mean(x_limits)
    y_mean = np.mean(y_limits)
    z_mean = np.mean(z_limits)

    # The plot bounding box is a sphere in the sense of the infinity
    # norm, hence I call half the max range the plot radius.
    plot_radius = 0.4*max([x_range, y_range, z_range])

    ax.set_xlim3d([x_mean - plot_radius, x_mean + plot_radius])
    ax.set_ylim3d([y_mean - plot_radius, y_mean + plot_radius])
    ax.set_zlim3d([z_mean - plot_radius, z_mean + plot_radius])

def plot_ellipse(ax, g, n=50):
    s = np.array([.02,.02,.005])
    # Set of all spherical angles:
    u = np.linspace(0, 2 * np.pi, n)
    v = np.linspace(0, np.pi, n)
    # Cartesian coordinates that correspond to the spherical angles:
    # (this is the equation of an ellipsoid):
    x = s[0] * np.outer(np.cos(u), np.sin(v))
    y = s[1] * np.outer(np.sin(u), np.sin(v))
    z = s[2] * np.outer(np.ones_like(u), np.cos(v))
    for i in range(n):
        for j in range(n):
            pt = np.array([x[i, j], y[i, j], z[i, j], 1.0])
            rpt = g.dot(pt)
            x[i, j] = rpt[0]
            y[i, j] = rpt[1]
            z[i, j] = rpt[2]
    # Plot:
    ax.plot_surface(x, y, z,  rstride=4, cstride=4, color='b')


def plot_simple_ellipse(ax, g, n=50):
    ax.scatter(g[0,3],g[1,3],g[2,3],s=10,c='b')
