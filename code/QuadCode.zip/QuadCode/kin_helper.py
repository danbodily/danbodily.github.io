#!/usr/bin/env python
import numpy as np
import math
import scipy as sp
# from scipy import linalg


def homog_translate(x, y, z):
    g = np.eye(4)
    g[0, 3] = x
    g[1, 3] = y
    g[2, 3] = z
    return g

def rot_vec2homog(R, p):
    return np.vstack((
        np.hstack((R, p.reshape(3, 1))),
        np.array([0, 0, 0, 1])
        ))
