#!/usr/bin/env python
import numpy as np
g = 9.81
m = .25
mp = m/4.0
L = .05
r = L/3.0
Ixx = 2*(mp*r**2/4.0)+2*(mp*r**2/4.0+mp*L**2)
Iyy = 2*(mp*r**2/4.0)+2*(mp*r**2/4.0+mp*L**2)
Izz = 4*(mp*r**2/2.0+mp*L**2)


#Initial States
#EulerAngles (In Inertial Frame)
psi0 = 0.0
th0 = 0.0
phi0 = 0.0

#Body Fixed Angle Rates
p0 = 0
q0 = 0
r0 = 0

#Positions Relative to Inertial Frame
p_n0 = -.2
p_e0 = -.2
p_d0 = 0
#Body Fixed Velocities
u0 = 0.0
v0 = 0.0
w0 = 0.0

initial_states = [psi0,th0,phi0,p0,q0,r0,p_n0,p_e0,p_d0,u0,v0,w0]
